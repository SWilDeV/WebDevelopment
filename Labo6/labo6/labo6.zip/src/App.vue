<template>
  <div id="app">
    <home />
  </div>
</template>

<script>
import home from "./components/home";

export default {
  name: "App",
  components: {
    home,
  },
};
</script>

<style></style>
